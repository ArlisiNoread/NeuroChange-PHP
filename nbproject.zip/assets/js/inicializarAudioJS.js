audiojs.events.ready(function() {
    var as = audiojs.createAll();
});
